# Woyera Data Quality API

This is a library to interact with the Woyera Data Quality API. 

Visit [www.woyera.com](www.woyera.com) to create an account and read the documentation on how to interact with the API.

Happy Data Error Detection!