# Woyera Data Quality API

This is a library to interact with the Data Projet Manager API. 

Visit [www.dataprojectmanager.com](www.dataprojectmanager.com) to create an account and read the documentation on how to interact with the API.

Happy Data Error Detection!